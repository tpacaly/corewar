/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/01 16:47:24 by tpacaly           #+#    #+#             */
/*   Updated: 2018/05/01 16:47:25 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/corewar.h"

void		ft_free_all_vm(t_vm *env)
{
	t_champ *h;
	t_champ *g;

	h = env->champ;
	while (h->next)
	{
		g = h->next;
		ft_memdel((void **)&h);
		h = g;
	}
	ft_memdel((void **)&h);
	ft_strdel((char **)&env->arene);
}

void		ft_dump(t_vm *env)
{
	int i;

	if (env->dump_aff == 1)
	{
		i = 1;
		ft_put("0x0000:", ' ', 1, 0);
		while (i < 0x1000)
		{
			ft_put(ft_itoa_base(env->arene[i], 16), ' ', 1, 1);
			i++;
			if ((i % 0x40) == 0)
			{
				ft_put("\n0x0", '0', 1, 0);
				ft_put(ft_itoa_base(i, 16), 0, 1, 1);
				write(1, ": ", 2);
			}
		}
	}
}

int			is_num_in_list(t_champ *champ, int n)
{
	champ = champ->next;
	while (champ)
	{
		if (champ->id == n)
			return (1);
		champ = champ->next;
	}
	return (0);
}

void		organise_num(t_champ *champ)
{
	t_champ *act;

	act = champ;
	while (champ)
	{
		if (is_num_in_list(champ, champ->id) == 1)
		{
			champ->id = (champ->id > 8) ? 1 : champ->id + 1;
			champ = act;
		}
		else
			champ = champ->next;
	}
}
