/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   strlen.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/05/01 17:02:38 by tpacaly           #+#    #+#             */
/*   Updated: 2018/05/01 17:02:38 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/corewar.h"

size_t	ft_strlen(const char *str)
{
	size_t index;

	index = 0;
	if (!str)
		return (0);
	while (str[index])
		index++;
	return (index);
}
