/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read_ins.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/11 14:38:09 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/11 14:38:41 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/vm.h"

int				ft_read_ins_ext(char *ins, char opcode, t_player pl)
{
	if (opcode == 1)
		return (ft_live());
	if (opcode == 2 || opcode == 0xD)
		return (ft_ld());
	if (opcode == 3)
		return (ft_st());
	if (opcode == 4 || opcode == 5)
		return (ft_addsub());
	if (opcode == 6 || opcode == 7 || opcode == 8)
		return (ft_andorxor());
	if (opcode == 9)
		return (ft_zjump());
	if (opcode == 0xA || opcode == 0xE)
		return (ft_ldi());
	if (opcode == 0xB)
		return (ft_sti());
	if (opcode == 0xC || opcode == 0xF)
		return (ft_fork());
	if (opcode == 0x10)
		return (ft_aff());
	else
		return (-1);
}

t_gen			ft_read_ins0(t_gen *general)
{

}