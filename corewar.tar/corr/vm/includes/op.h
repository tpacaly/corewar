/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/05 14:35:05 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/11 14:48:37 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OP_H
# define OP_H

# define MEM_SIZE				(8*1024)
# define CHAMP_MAX_SIZE			(MEM_SIZE / 6)
# define BUFF_SIZE				(CHAMP_MAX_SIZE)
# define PROG_NAME_LENGTH		(128)
# define COMMENT_LENGTH			(2048)
#endif

