/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vm.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/11 14:45:34 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/11 14:45:54 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef VM_H
# define VM_H

#include "op.h"

typedef struct		s_player
{
   char				name[PROG_NAME_LENGTH + 1];
   char				comment[COMMENT_LENGTH];
   struct t_player	*next;
   char				*instructions;
}

typedef struct		s_gen
{
   int				nb_players;
   t_player			*players;
   t_cpu			*first;
   int				cycles_to_die;
}                   t_gen;

typedef struct		s_cpu
{
	int				cycle_wait;
	struct s_cpu	*next;
}					t_cpu;

typedef struct       s_cpu
{
   char           name[128];
   char           comment[1024];
   unsigned int      reg[REG_NUMBER];
   int               pc;
   int               carry;
   int               cycle_wait;
   int               size;
   unsigned char     *code;
   int               live;
   unsigned int      uid;
   unsigned char     color;
   struct s_cpu      *next;
}                 t_cpu;

#endif