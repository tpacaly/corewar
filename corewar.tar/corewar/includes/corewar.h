/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   corewar.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/24 11:22:08 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/24 11:22:52 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef COREWAR_H
# define COREWAR_H

# include <stdlib.h>
# include <string.h>
# include <unistd.h>
# include <limits.h>
# include <stdio.h>
# include <fcntl.h>
#include "../LIBFT/libft.h"
#include "op.h"

# define IND_SIZE				2
# define REG_SIZE				4
# define DIR_SIZE				REG_SIZE
# define CYCLE_TO_DIE			1500
# define CYCLE_DELTA			1150
# define REG_NUMBER				16
# define MAX_ARGS_NUMBER		4
# define MAX_PLAYERS			4
# define IDX_MOD				(MEM_SIZE / 8)

typedef struct			s_champ
{
	int					id;
	t_header			head;
	int					fd;
	unsigned char		*action;
	unsigned long long	cycle;
	unsigned long long	pc;
	char				carry;
	char				live;
	unsigned char		registre[REG_SIZE * REG_NUMBER];
	struct s_champ		*next;
}						t_champ;

typedef struct			s_vm
{
	long				nbr_cycles;
	int					winner;
	char				*winn;
	t_champ				*champ;
	unsigned char		*arene;
}						t_vm;

void					ft_vm_error(char *error);
long					check_live(t_vm *env);
int						put_name(int *cur, char **av);
void					make_arene(t_vm *env);
void					make_player(t_vm *env, int nbr);
void					rang(t_vm *env, t_champ *champ);
void					set_carry(t_champ *champ, t_champ *ref);
void					give_live(t_champ *champ, int id, t_vm *env);
void					exec(t_vm *env, t_champ *champ);
void					exec2(t_vm *env, t_champ *champ, unsigned char \
						commande);
void					exec3(t_vm *env, t_champ *champ, unsigned char \
						commande);
void					exec4(t_vm *env, t_champ *champ, unsigned char \
						commande);
void					exec5(t_vm *env, t_champ *champ, unsigned char \
						commande);
void					exec6(t_vm *env, t_champ *champ, unsigned char \
						commande);
short					get_short(unsigned char *read);
int						get_int(unsigned char *read);
short					get_short2(void *read);
int						get_int2(unsigned char *read);
int						oct_codage(char target, char place, unsigned char \
						value);
void					live(unsigned char *arene, t_champ *champ, t_vm *env);
void					ld(t_vm *env, unsigned char *arene, t_champ *champ);
void					st(t_vm *env, unsigned char *arene, t_champ *champ);
void					add(t_vm *env, unsigned char *arene, t_champ *champ);
void					sub(t_vm *env, unsigned char *arene, t_champ *champ);
void					and(unsigned char *arene, t_champ *champ);
void					or(unsigned char *arene, t_champ *champ);
void					xor(unsigned char *arene, t_champ *champ);
void					zjump(t_vm *env, unsigned char *arene, t_champ *champ);
void					ldi(unsigned char *arene, t_champ *champ);
void					sti(unsigned char *arene, t_champ *champ);
void					f_fork(unsigned char *arene, t_champ *champ, \
						t_vm *env);
void					lld(t_vm *env, unsigned char *arene, t_champ *champ);
void					lldi(unsigned char *arene, t_champ *champ);
void					f_lfork(unsigned char *arene, t_champ *champ, \
						t_vm *env);
void					aff(unsigned char *arene, t_champ *champ);

#endif