/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/24 11:30:18 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/28 10:55:50 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/corewar.h"

void	ft_put(char *str, char c, char fd, char bool_free)
{
	if (!str)
		return ;
	write(fd, str, ft_strlen(str));
	(c != 0) ? write(fd, &c, 1) : 0;
	(bool_free == 1) ? ft_strdel(&str) : 0;
}

int	ft_free_all_vm(t_vm *strukt)
{
	t_champ	*del_champ;
	t_champ	*del_champ0;

	ft_strdel((char**)&strukt->arene);
	ft_strdel(&strukt->winn);
	del_champ = strukt->champ;
	while(del_champ != NULL)
	{
		del_champ0 = del_champ->next;
		ft_memdel((void**)&del_champ);
		del_champ = del_champ0;
	}
	return(0);
}

