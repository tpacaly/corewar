/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   octet_codage.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tpacaly <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/04/24 15:34:17 by tpacaly           #+#    #+#             */
/*   Updated: 2018/04/24 15:34:18 by tpacaly          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/corewar.h"

int	ft_free_all_vm(t_vm *strukt)
{
	t_champ	*del_champ;
	t_champ	*del_champ0;

	ft_strdel((char**)&strukt->arene);
	ft_strdel(&strukt->winn);
	del_champ = strukt->champ;
	while(del_champ != NULL)
	{
		del_champ0 = del_champ->next;
		ft_memdel((void**)&del_champ);
		del_champ = del_champ0;
	}
	return(0);
}

static	int	third_place(char target, char place, unsigned char value)
{
	if (value >= 12 && target == 3 && place == 3)
		return (1);
	else if (value >= 8 && target == 2 && place == 3)
		return (1);
	else if (value < 8 && target == 1 && place == 3)
		return (1);
	return (0);
}

static	int	second_place(char target, char place, unsigned char value)
{
	if (value >= 48 && target == 3 && place == 2)
		return (1);
	else if (value >= 32 && target == 2 && place == 2)
		return (1);
	else if (value < 32 && target == 1 && place == 2)
		return (1);
	if (value >= 32)
		value -= 32;
	if (value >= 16)
		value -= 16;
	return (third_place(target, place, value));
}

int			oct_codage(char target, char place, unsigned char value)
{
	if (value >= 192 && target == 3 && place == 1)
		return (1);
	else if (value >= 128 && target == 2 && place == 1)
		return (1);
	else if (value < 128 && target == 1 && place == 1)
		return (1);
	if (value >= 128)
		value -= 128;
	if (value >= 64)
		value -= 64;
	return (second_place(target, place, value));
}
